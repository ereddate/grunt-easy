// 包装函数
module.exports = function(grunt) {

  // 任务加载
  grunt.loadNpmTasks('grunt-cmd-transport');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-cmd-concat');
  //grunt.loadNpmTasks('grunt-ssh');
  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-include-replace');

  var config = grunt.file.readJSON('spm.json'),
    args = {};
  for (name in config.args) {
    args[name] = grunt.file.readJSON(config.args[name] + "spm.json");
  }
  var concats = [],
    uglifys = [],
    lessBuilder = {},
    lesscss;

  function extend(target, args) {
    if (typeof args == "array" && !!args.length && args.length > 0) {
      target = target || [];
      var i, len;
      for (i = 0; i < (len = args.length); i++) {
        target.push(args[i]);
      }
    } else {
      target = target || {};
      for (name in args) {
        target[name] = args[name];
      }
    }
    return target;
  }

  function tmpl(str, args) {
    var name;
    for (name in args) {
      var regx = new RegExp("\\\<\\\%\\\=\\s*" + name + "\\s*\\\%\\\>", "gi");
      str = str.replace(regx, args[name]);
    }
    return str;
  }

  String.prototype.tmpl = function(args) {
    return tmpl(this, args);
  };

  //基本配置
  var gruntConfig = {
    //transport: {},
    concat: {
      options: {
        noncmd: true
      }
    },
    uglify: {
      options: {
        report: "gzip"
      }
    },
    /*secret: grunt.file.readJSON('secret.json'),
          sftp: {
            dev_concat_javascript: {
              options: {
                path: '<%= secret.dev.path %>',
                host: '<%= secret.dev.host %>',
                username: '<%= secret.dev.username %>',
                password: '<%= secret.dev.password %>',
                showProgress: true
              },
              files: extend({
                  'dist/<%= pkg.version %>/js/config.<%= pkg.version %>.min.js': 'dist/<%= pkg.version %>/js/config.<%= pkg.version %>.min.js',
                  'dist/<%= pkg.version %>/libs/libs.<%= pkg.version %>.min.js': 'dist/<%= pkg.version %>/libs/libs.<%= pkg.version %>.min.js'
                }, ftpConcat)
            },
            dev_dist_javascript: {
              options: {
                path: '<%= secret.dev.path %>',
                host: '<%= secret.dev.host %>',
                username: '<%= secret.dev.username %>',
                password: '<%= secret.dev.password %>',
                showProgress: true
              },
              files: extend({
                  'dist/<%= pkg.version %>/js/config.<%= pkg.version %>.min.js': 'dist/<%= pkg.version %>/js/config.<%= pkg.version %>.min.js',
                  'dist/<%= pkg.version %>/libs/libs.<%= pkg.version %>.min.js': 'dist/<%= pkg.version %>/libs/libs.<%= pkg.version %>.min.js'
                }, ftpUglify)
            }
    },*/
    less: {
      options: {
        compress: false,
        yuicompress: false
      }
    },
    includereplace: {
      options: {
        prefix: '<!-- @@',
        suffix: ' -->',
        includesDir: './'
      }
      /*,
            test: {
              files: [{
                src: 'trunk/test/html/*.html',
                dest: 'dist/test/html/'
              }]
            }*/
    },
    watch: {
      options: {
        event: ['changed'],
        livereload: true
      },
      configs: {
        options: {
          reload: true
        },
        files: ["Gruntfile.js", "package.json", "spm.json", "trunk/**/js/*.json"],
        event: ["changed"]
      }
    }
  };

  //文件的合并和压缩
  var jsProjectName, jsProjectVer, jsModuleName, jsModules, jsProjectBaseName, jsProjectConcatOps, jsProjectUglifyOps, cssProjectName, cssProjectVer, cssFiles, alias, taskName, watchName;


  for (jsProjectName in args) {
    var user = args[jsProjectName].user;
    //判断是否支持require
    if ("transport" in args[jsProjectName]) {
      gruntConfig["transport"] = {};
      alias = args[jsProjectName]["transport"].options.alias = extend(config.alias, args[jsProjectName]["transport"].options.alias);

      gruntConfig["transport"][jsProjectName] = extend(args[jsProjectName]["transport"], {
        "files": [{
          "expand": true,
          "cwd": "",
          "src": ["trunk/" + jsProjectName + "/js/**/**/*.js", "modules/js/**/**/*.js"],
          "dest": "temp/" + jsProjectName + "/"
        }]
      });
    }

    jsModules = args[jsProjectName]["modules"];
    jsProjectVer = jsModules.version;
    jsProjectBaseName = args[jsProjectName].name;

    jsProjectConcatOps = {
      options: {
        footer: '\n/*! time:<%= grunt.template.today("yyyy-mm-dd") %> end \*\/',
        banner: ('\n/*! <%= name %> ' + user + ' start\*\/').tmpl({
          name: jsProjectBaseName
        })
      }
    };

    jsProjectUglifyOps = {
      options: {
        banner: ('\n/*! <%= name %> ' + user + ' start\*\/').tmpl({
          name: jsProjectBaseName
        }),
        footer: '\n/*! time:<%= grunt.template.today("yyyy-mm-dd") %> end \*\/',
        mangle: false, //不混淆变量名
        preserveComments: false //删除注释，还可以为 false（删除全部注释），some（保留@preserve @license @cc_on等注释）
      }
    };

    //合并、压缩控制
    for (jsModuleName in jsModules["files"]) {

      var obj = jsModules["files"][jsModuleName];
      for (i = 0; i < obj.concat.src.length; i++) {
        obj.concat.src[i] = obj.concat.src[i].tmpl(extend(alias, {
          name: jsProjectBaseName
        }));
      }

      obj && obj.concat && concats.push({
        src: obj.concat.src,
        dest: obj.concat.dest.tmpl({
          ver: jsProjectVer,
          name: jsProjectBaseName
        })
      });
      obj && obj.uglify && uglifys.push({
        src: obj.uglify.src.tmpl({
          ver: jsProjectVer,
          name: jsProjectBaseName
        }),
        dest: obj.uglify.dest.tmpl({
          ver: jsProjectVer,
          name: jsProjectBaseName
        })
      });

    }

    var libs = args[jsProjectName]["libs"],
      libstr = jsProjectName + "/libs/" + libs.version + "/libs." + libs.version;

    concats.push(extend({
      "dest": "src/" + libstr + ".concat.js"
    }, {
      src: libs.concat,
    }));

    uglifys.push(extend({
      "src": "src/" + libstr + ".concat.js",
      "dest": "dist/" + libstr + ".min.js"
    }, libs.uglify));

    gruntConfig.concat[jsProjectName] = {
      options: jsProjectConcatOps.options,
      files: concats
    };

    gruntConfig.uglify[jsProjectName] = {
      options: jsProjectUglifyOps.options,
      files: uglifys
    };

    //less配置控制
    lessBuilder = {};
    lesscss = args[jsProjectName].less;
    for (cssName in lesscss) {
      cssProjectName = lesscss[cssName].name;
      cssProjectVer = lesscss[cssName].version;
      cssFiles = lesscss[cssName]["files"];

      for (i = 0; i < cssFiles.length; i++) {
        lessBuilder[(cssFiles[i].dist).tmpl({
          name: cssProjectName,
          ver: cssProjectVer
        })] = cssFiles[i].src;
      }

      gruntConfig.less[cssName] = {
        options: {
          banner: ('\n/*! <%= name %>.<%= ver %> ' + user + ' \*\/\n/*! time:<%= grunt.template.today("yyyy-mm-dd") %> \*\/').tmpl({
            name: cssProjectName,
            ver: cssProjectVer
          }),
          compress: !lesscss[cssName].debug ? true : false,
          yuicompress: !lesscss[cssName].debug ? true : false,
        },
        files: lessBuilder
      };
    }

    var htmlbuild = args[jsProjectName]["htmlbuild"];
    gruntConfig.includereplace[jsProjectName] = extend({
      "src": "*.html",
      "dest": "dist/" + jsProjectName + "/html/" + htmlbuild.version + "/",
      expand: true,
      cwd: "trunk/" + jsProjectName + "/html/"
    }, htmlbuild);

    //任务控制
    var tasksName = {
        "js": ["concat:" + jsProjectName, "uglify:" + jsProjectName],
        "less": ["less:" + jsProjectName],
        "html": ["includereplace:" + jsProjectName]
      },
      tname;
    var tasks = args[jsProjectName]["tasks"];
    tasks && extend(tasksName, tasks);
    for (tname in tasksName) {
      var tasksDF = tasksName[tname];
      if ("transport" in args[jsProjectName] && tname == "js" && tasksName[tname][0] != ("transport:" + jsProjectName)) {
        tasksName[tname].unshift("transport:" + jsProjectName);
        tasksDF = tasksName[tname];
      }
      grunt.registerTask(jsProjectName + "-" + tname, tasksDF);
    }

    //监控配置
    var watchs = args[jsProjectName]["watch"],
      watchDf = {
        "css": {
          "files": ["trunk/" + jsProjectName + "/css/*.less", "modules/css/**/*.less"],
          "tasks": [jsProjectName + "-less"]
        },
        "javascript": {
          "files": ["trunk/" + jsProjectName + "/js/**/*.js", "modules/js/**/*.js"],
          "tasks": [jsProjectName + "-js"]
        },
        "html": {
          "files": ["trunk/" + jsProjectName + "/html/**/*.html", "modules/html/*.html"],
          "tasks": [jsProjectName + "-html"]
        }
      };
    watchs && extend(watchDf, watchs);
    for (watchName in watchDf) {
      gruntConfig.watch[jsProjectName + "-" + watchName] = watchDf[watchName];
    }

  }

  // 任务配置
  grunt.initConfig(gruntConfig);

};