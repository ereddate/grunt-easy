define("modules/js/header/header.0.0.1", [], function(require, exports, module) {
    return "header";
});
