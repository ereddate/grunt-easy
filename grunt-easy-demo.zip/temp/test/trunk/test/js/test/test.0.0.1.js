define("trunk/test/js/test/test.0.0.1", [ "header" ], function(require, exports, module) {
    var header = require("modules/js/header/header.0.0.1");
    console.log(header);
    console.log("test");
});
