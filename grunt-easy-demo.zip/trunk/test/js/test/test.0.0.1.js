define(function(require, exports, module){
	var header = require("header");
	console.log(header);
	console.log("test");
});