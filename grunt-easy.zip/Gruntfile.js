// 包装函数

module.exports = function(grunt) {

  // 任务加载
  grunt.loadNpmTasks('grunt-cmd-transport');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-cmd-concat');
  //grunt.loadNpmTasks('grunt-ssh');
  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-include-replace');
  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-css-sprite');
  grunt.loadNpmTasks('grunt-contrib-copy');

  //require('load-grunt-tasks')(grunt);
  //grunt.loadNpmTasks('grunt-concurrent');
  var htmlEncode = require("./htmlencode").encode,
    htmlTmpl = require("./htmltmpl").tmpl;

  var config = grunt.file.readJSON('spm.json'),
    args = {};
  for (name in config.args) {
    args[name] = grunt.file.readJSON(config.args[name] + "spm.json");
  }
  var concats = [],
    uglifys = [],
    lessBuilder = {},
    lesscss;

  function r(a) {
    var b = "length" in a && a.length,
      c = (typeof a).toLowerCase();
    return "array" === c || 0 === b || "number" == typeof b && b > 0 && b - 1 in a
  }

  var mod = function(item) {
    return new mod.fn.init(item);
  };
  mod.fn = mod.prototype = {
    init: function(item) {
      var self = this;
      if (r(item)) {
        mod.each(item, function(i, obj) {
          self[i] = obj;
        });
        self.length = item.length;
      } else {
        self[0] = item;
        self.length = 0;
      }
      var self = this;
      return this;
    },
    extend: function(args) {
      return mod.extend(this, args);
    },
    each: function(b, c) {
      var target = this.length == 0 ? this[0] : this;
      return mod.each(target, b, c);
    }
  };
  mod.fn.init.prototype = mod.fn;

  mod.each = function(a, b, c) {
    var d, e = 0,
      f = a.length,
      g = r(a);
    if (c) {
      if (g) {
        for (; f > e; e++)
          if (d = b.apply(a[e], c), d === !1) break
      } else
        for (e in a)
          if (d = b.apply(a[e], c), d === !1) break
    } else if (g) {
      for (; f > e; e++)
        if (d = b.call(a[e], e, a[e]), d === !1) break
    } else
      for (e in a)
        if (d = b.call(a[e], e, a[e]), d === !1) break;
    return a
  };

  mod.q = require("q");

  mod.extend = function(target, args) {
    if (typeof args == "array" && !!args.length && args.length > 0) {
      target = target || [];
      var i, len;
      for (i = 0; i < (len = args.length); i++) {
        target.push(args[i]);
      }
    } else {
      target = target || {};
      for (name in args) {
        target[name] = args[name];
      }
    }
    return target;
  };

  mod.tmpl = function(str, args) {
    var name;
    for (name in args) {
      var regx = new RegExp("\\\<\\\%\\\=\\s*" + name + "\\s*\\\%\\\>", "gi");
      str = str.replace(regx, args[name]);
    }
    return str;
  }

  String.prototype.tmpl = function(args) {
    return mod.tmpl(this, args);
  };

  //基本配置
  var gruntConfig = {
    //transport: {},
    concat: {
      options: {
        noncmd: true
      }
    },
    uglify: {
      options: {
        report: "gzip"
      }
    },
    /*secret: grunt.file.readJSON('secret.json'),
          sftp: {
            dev_concat_javascript: {
              options: {
                path: '<%= secret.dev.path %>',
                host: '<%= secret.dev.host %>',
                username: '<%= secret.dev.username %>',
                password: '<%= secret.dev.password %>',
                showProgress: true
              },
              files: extend({
                  'dist/<%= pkg.version %>/js/config.<%= pkg.version %>.min.js': 'dist/<%= pkg.version %>/js/config.<%= pkg.version %>.min.js',
                  'dist/<%= pkg.version %>/libs/libs.<%= pkg.version %>.min.js': 'dist/<%= pkg.version %>/libs/libs.<%= pkg.version %>.min.js'
                }, ftpConcat)
            },
            dev_dist_javascript: {
              options: {
                path: '<%= secret.dev.path %>',
                host: '<%= secret.dev.host %>',
                username: '<%= secret.dev.username %>',
                password: '<%= secret.dev.password %>',
                showProgress: true
              },
              files: extend({
                  'dist/<%= pkg.version %>/js/config.<%= pkg.version %>.min.js': 'dist/<%= pkg.version %>/js/config.<%= pkg.version %>.min.js',
                  'dist/<%= pkg.version %>/libs/libs.<%= pkg.version %>.min.js': 'dist/<%= pkg.version %>/libs/libs.<%= pkg.version %>.min.js'
                }, ftpUglify)
            }
    },*/
    cssmin: {
      options: {
        shorthandCompacting: false,
        roundingPrecision: -1
      }
    },
    less: {
      options: {
        compress: false,
        yuicompress: false
      }
    },
    sprite: {},
    copy: {},
    includereplace: {
      options: {
        prefix: '<!-- @@',
        suffix: ' -->',
        includesDir: './'
      }
      /*,
            test: {
              files: [{
                src: 'trunk/test/html/*.html',
                dest: 'dist/test/html/'
              }]
            }*/
    },
    jshint: {},
    //concurrent:{}, //多任务
    watch: {
      options: {
        event: ['changed'],
        livereload: true
      },
      configs: {
        options: {
          reload: true
        },
        files: ["Gruntfile.js", "package.json", "spm.json", "trunk/**/js/*.json", "customTasks.js"],
        event: ["changed"]
      }
    }
  };

  //文件的合并和压缩
  var jsProjectName, jsProjectVer, jsModuleName, jsModules, jsProjectBaseName, jsProjectConcatOps, jsProjectUglifyOps, cssProjectName, cssProjectVer, cssFiles, alias, taskName, watchName;

  mod(args).each(function(jsProjectName, local) {

    var user = local.user;
    alias = mod.extend(config.alias, local["alias"]);
    //判断是否支持require
    if ("transport" in local) {
      gruntConfig["transport"] = {};

      local["transport"].options.alias = alias;

      gruntConfig["transport"][jsProjectName] = mod.extend(local["transport"], {
        "files": [{
          "expand": true,
          "cwd": "",
          "src": ["trunk/" + jsProjectName + "/js/**/**/*.js", "modules/js/**/**/*.js"],
          "dest": "temp/" + jsProjectName + "/"
        }]
      });
    }

    jsModules = local["modules"];
    jsProjectVer = jsModules.version;
    jsProjectBaseName = local.name;

    jsProjectConcatOps = {
      options: {
        footer: '\n/*! time:<%= grunt.template.today("yyyy-mm-dd") %> end \*\/',
        banner: ('\n/*! <%= name %> ' + user + ' start\*\/').tmpl({
          name: jsProjectBaseName
        })
      }
    };

    jsProjectUglifyOps = {
      options: {
        banner: ('\n/*! <%= name %> ' + user + ' start\*\/').tmpl({
          name: jsProjectBaseName
        }),
        footer: '\n/*! time:<%= grunt.template.today("yyyy-mm-dd") %> end \*\/',
        mangle: false, //不混淆变量名
        preserveComments: false //删除注释，还可以为 false（删除全部注释），some（保留@preserve @license @cc_on等注释）
      }
    };

    //合并、压缩控制
    concats.length = 0;
    uglifys.length = 0;
    mod(jsModules["files"]).each(function(jsModuleName, obj) {

      //var obj = jsModules["files"][jsModuleName];
      //console.log(alias)
      for (i = 0; i < obj.length; i++) {
        obj[i] = obj[i].tmpl(mod.extend(alias, {
          name: jsProjectBaseName
        }));
      }

      //console.log(obj.concat.src)

      concats.push({
        src: obj,
        dest: "src/" + jsProjectBaseName + "/" + jsProjectVer + "/" + jsModuleName + "/" + jsModuleName + "." + jsProjectVer + ".concat.js"
      });
      uglifys.push({
        src: "src/" + jsProjectBaseName + "/" + jsProjectVer + "/" + jsModuleName + "/" + jsModuleName + "." + jsProjectVer + ".concat.js",
        dest: "dist/" + jsProjectBaseName + "/js/" + jsProjectVer + "/" + jsModuleName + "/" + jsModuleName + "." + jsProjectVer + ".min.js"
      });

    });

    var libs = local["libs"],
      libstr = jsProjectName + "/libs/" + libs.version + "/libs." + libs.version;

    concats.push(mod.extend({
      "dest": "src/" + libstr + ".concat.js"
    }, {
      src: libs.concat,
    }));

    uglifys.push(mod.extend({
      "src": "src/" + libstr + ".concat.js",
      "dest": "dist/" + libstr + ".min.js"
    }, libs.uglify));

    gruntConfig.concat[jsProjectName] = {
      options: jsProjectConcatOps.options,
      files: concats
    };

    gruntConfig.uglify[jsProjectName] = {
      options: jsProjectUglifyOps.options,
      files: uglifys
    };

    //less配置控制
    lessBuilder = {};
    lesscss = local.less;
    //mod(lesscss).each(function(cssName, obj) {
    //cssProjectName = lesscss.name;
    cssProjectVer = lesscss.version;
    cssFiles = lesscss["files"];

    function _type(o) {
      if (o != null && o.constructor != null) {
        return Object.prototype.toString.call(o).slice(8, -1);
      } else {
        return '';
      }
    }

    mod.each(cssFiles, function(name, val) { //for (i = 0; i < cssFiles.length; i++) {
      if (_type(cssFiles).toLowerCase() != "array") {
        var bname = ((lesscss.sprite ? "temp" : "dist") + "/<%= name %>/css/<%= ver %>/" + name + ".<%= ver %>." + (lesscss.sprite ? "debug" : "min") + ".css").tmpl({
          name: jsProjectName,
          ver: cssProjectVer
        });
        lessBuilder[bname] = val;
      } else {
        lessBuilder[(obj.dist).tmpl({
          name: jsProjectName,
          ver: cssProjectVer
        })] = obj.src;
      }
    });

    gruntConfig.less[jsProjectName] = {
      options: {
        banner: ('\n/*! <%= name %>.<%= ver %> ' + user + ' \*\/\n/*! time:<%= grunt.template.today("yyyy-mm-dd") %> \*\/').tmpl({
          name: jsProjectName,
          ver: cssProjectVer
        }),
        compress: !lesscss.debug ? true : false,
        yuicompress: !lesscss.debug ? true : false,
      },
      files: lessBuilder
    };
    //});

    /*if ("cssmin" in lesscss) {
      gruntConfig.cssmin[jsProjectName] = local.less["cssmin"];
    }*/

    if (lesscss.sprite) {
      gruntConfig.sprite[jsProjectName] = {
        options: {
          // 映射CSS中背景路径，支持函数和数组，默认为 null
          imagepath_map: null,
          // 各图片间间距，如果设置为奇数，会强制+1以保证生成的2x图片为偶数宽高，默认 0
          padding: 2,
          // 是否使用 image-set 作为2x图片实现，默认不使用
          useimageset: false,
          // 是否以时间戳为文件名生成新的雪碧图文件，如果启用请注意清理之前生成的文件，默认不生成新文件
          newsprite: false,
          // 给雪碧图追加时间戳，默认不追加
          spritestamp: false,
          // 在CSS文件末尾追加时间戳，默认不追加
          cssstamp: false,
          // 默认使用二叉树最优排列算法
          algorithm: 'binary-tree',
          // 默认使用`pixelsmith`图像处理引擎
          engine: 'pixelsmith',
          // sprite背景图源文件夹
          imagepath: 'trunk/' + jsProjectName + '/imgs/',
          // 雪碧图输出目录，注意，会覆盖之前文件！默认 images/
          spritedest: 'dist/' + jsProjectName + '/imgs/',
          // 替换后的背景路径，默认 ../images/
          spritepath: '../../imgs/'
        },
        files: [{
          // 启用动态扩展
          expand: true,
          // css文件源的文件夹
          cwd: 'temp/' + jsProjectName + '/css/' + cssProjectVer + '/',
          // 导出css和sprite的路径地址
          dest: 'dist/' + jsProjectName + '/css/' + cssProjectVer + '/',
          // 匹配规则
          src: '*.css',
          // 导出的css名
          ext: "." + cssProjectVer + ".min.css"
        }]
      }
    }

    gruntConfig.copy[jsProjectName] = {
      files: [{
        expand: true,
        cwd: 'trunk/' + jsProjectName + '/imgs/',
        dest: 'dist/' + jsProjectName + '/imgs/',
        src: "*@2x.png",
        filter: 'isFile'
      }]
    };

    var htmlbuild = local["html"];
    gruntConfig.includereplace[jsProjectName] = mod.extend({
      options: {
        encoding: htmlbuild.baseEncode || "utf-8"
      },
      files: [{
        "src": "*.html",
        "dest": "dist/" + jsProjectName + "/html/" + htmlbuild.version + "/",
        expand: true,
        cwd: "trunk/" + jsProjectName + "/html/"
      }]
    }, htmlbuild);

    gruntConfig["jshint"][jsProjectName] = {
      files: {
        src: ["trunk/" + jsProjectName + "/js/**/*.js"]
      }
    };

    //任务控制
    var tasksName = {
        "js": ["jshint:" + jsProjectName, "concat:" + jsProjectName, "uglify:" + jsProjectName],
        "less": ["less:" + jsProjectName],
        "html": ["includereplace:" + jsProjectName]
      },
      tname;
    var tasks = local["tasks"];
    tasks && mod.extend(tasksName, tasks);
    mod(tasksName).each(function(tname, tasksDF) {
      //var tasksDF = tasksName[tname];
      if ("transport" in local && tname == "js" && tasksDF[0] != ("transport:" + jsProjectName)) {
        tasksDF.splice(1, 0, "transport:" + jsProjectName);
        //tasksDF = tasksName[tname];
      }
      if (lesscss.sprite && tname == "less" && tasksDF[0] != ("sprite:" + jsProjectName)) {
        tasksDF.splice(1, 0, "sprite:" + jsProjectName);
        tasksDF.splice(2, 0, "copy:" + jsProjectName);
      }
      if (lesscss.cssmin && tname == "less" && tasksDF[0] != ("cssmin:" + jsProjectName)) {
        gruntConfig.cssmin[jsProjectName] = local.less["cssmin"];
        tasksDF.splice(tasksDF.length, 0, "cssmin:" + jsProjectName);
        //tasksDF = tasksName[tname];
      }
      //console.log(tasksDF)
      grunt.registerTask(jsProjectName + "-" + tname, tasksDF);
    });

    //gruntConfig.concurrent[jsProjectName] = [jsProjectName + "-less", jsProjectName + "-js"];

    //html转码
    htmlbuild.tCode && grunt.task.registerTask(jsProjectName + "-htmlEncode", "html encode", function(eca, ecb) {
      if (htmlbuild.tCode.cmd && grunt.file.isDir(htmlbuild.tCode.cmd)) {
        console.log("start encode ...");
        htmlEncode({
          send: function(ops) {
            console.log(ops);
          }
        }, {
          cmd: htmlbuild.tCode.cmd,
          fcode: htmlbuild.baseEncode || "utf-8",
          tcode: htmlbuild.tCode.charset
        });
      }
    });

    htmlbuild.tmpl && grunt.task.registerTask(jsProjectName + "-tmpl", "html template", function(a, b) {
      if (htmlbuild.tmpl && grunt.file.isDir(htmlbuild.tmpl)) {
        console.log("start htmltmpl ...");
        htmlTmpl({
          send: function(ops) {
            console.log(ops);
          }
        }, {
          cmd: htmlbuild.tmpl
        });
      }
    });

    //监控配置
    var watchs = local["watch"],
      watchDf = {
        "css": {
          "files": ["trunk/" + jsProjectName + "/css/**/*.less", "modules/css/**/*.less"],
          "tasks": [jsProjectName + "-less"]
        },
        "javascript": {
          "files": ["trunk/" + jsProjectName + "/js/**/*.js", "modules/js/**/*.js"],
          "tasks": [jsProjectName + "-js"]
        },
        "html": {
          "files": ["trunk/" + jsProjectName + "/html/**/*.html", "modules/html/*.html"],
          "tasks": [jsProjectName + "-html"]
        }
      };

    if (htmlbuild.tCode) {
      watchDf.html.tasks.push(jsProjectName + "-htmlEncode");
    }
    if (htmlbuild.tmpl) {
      (watchDf["tmpl"] = {
        files: ["trunk/" + jsProjectName + "/html/**/*.tmpl"]
      }).tasks = [jsProjectName + "-tmpl"];
    }
    watchs && mod.extend(watchDf, watchs);
    mod.each(watchDf, function(watchName, obj) {
      gruntConfig.watch[jsProjectName + "-" + watchName] = obj;
    });

    require("./customTasks").extend.call(grunt, {
      usConfig: local,
      config: gruntConfig,
      mod: mod
    });
  });

  grunt.registerTask("default", ["watch"]);

  // 任务配置
  grunt.initConfig(gruntConfig);

};