exports.extend = function(ops) {
	/*  this = grunt,
		ops = {
			usConfig: spm.json,
			config: grunt-config,
			mod: mod{
				each: mod.each(array, function(i, arr){}) || mod(array).each(function(i, arr){}),
				extend: mod.extend(a, b) return a,
				tmpl: mod.tmpl("<%= name %>", {name: a}) || "<%= name %>".tmpl({name: a})
			}
		};
	*/
	switch (ops.usConfig.name) {
		case "h5":
			console.log("customTasks.js, name:" + ops.usConfig.name);
			break;
		case "demo/newh5":
			var a = require("./trunk/demo/newh5/js/customTask.js");
			console.log("customTasks.js, name:" + ops.usConfig.name);
			a.call(this, ops);
			break;
	}

};