var fs = require('fs'),
	iconv = require('iconv-lite'),
	readFile = require('./readDirFiles').read;

/*function readFile(dir) {
		var file_type = ['html', 'htm'];
		var files = fs.readdirSync(dir);
		var def = function() {
			var deferred = Q.defer();
			files.forEach(function(file) {
				var pathname = dir + '/' + file,
					stat = fs.lstatSync(pathname);
				if (!stat.isDirectory()) {
					var name = file.toString();
					if (!file_type.inarray(name.substring(name.lastIndexOf('.') + 1))) {
						return;
					}
					var filename = dir + "/" + file.replace(/\.html/, "." + query.tcode + ".html");
					var regex = new RegExp("\\." + query.tcode + "\\.", "gi");
					if (regex.test(file)) {
						res && res.send({
							status: 0,
							msg: 'error!',
							code: "File already exists."
						});
						return;
					}
					console.log(filename);
					try{
						fs.writeFileSync(filename, iconv.encode(iconv.decode(fs.readFileSync(pathname), query.fcode), query.tcode));
					}catch(err){
						deferred.reject(err);
					}
				} else {
					readFile(pathname);
				}
			});
			deferred.resolve();
			return deferred.promise;
		};
		def().then(function() {
			res && res.send({
				status: 1,
				msg: 'end!',
				code: ""
			});
		}, function(err) {
			res && res.send({
				status: 0,
				msg: 'error!',
				code: err
			});
		});
	}*/
/*function readFile(dir, callback, res, query) {
	var file_type = ['html', 'htm'];
	var files = fs.readdirSync(dir);
	var def = function() {
		var deferred = Q.defer();
		files.forEach(function(file) {
			var pathname = dir + '/' + file,
				stat = fs.lstatSync(pathname);
			if (!stat.isDirectory()) {
				var name = file.toString();
				if (!file_type.inarray(name.substring(name.lastIndexOf('.') + 1))) {
					return;
				}
				var regex = new RegExp("\\." + query.tcode + "\\.", "gi");
				if (regex.test(file)) {
					res && res.send({
						status: 0,
						msg: 'error!',
						code: "File already exists."
					});
					return;
				}
				callback && callback(pathname);

			} else {
				readFile(pathname, callback, res, query);
			}
		});
		deferred.resolve();
		return deferred.promise;
	};
	def().then(function() {
		res && res.send({
			status: 1,
			msg: 'end!',
			code: ""
		});
	}, function(err) {
		res && res.send({
			status: 0,
			msg: 'error!',
			code: err
		});
	});
}*/

exports.encode = function(res, query) {
	console.log(query)
	var dir = query.cmd;


	readFile(dir, function(pathname, deferred) {
		console.log(pathname)
		var regex = new RegExp("\\\." + query.tcode + "\\\.html", "gim");
		var filename = !regex.test(pathname) ? pathname.replace(/\.html/, "." + query.tcode + ".html") : pathname;
		regex = new RegExp("\\." + query.tcode + "\\.", "gim");
		if (regex.test(pathname)) {
			fs.unlink(pathname);
		}
		//console.log(filename);
		try {
			fs.writeFileSync(filename, iconv.encode(iconv.decode(fs.readFileSync(pathname), query.fcode), query.tcode));
		} catch (err) {
			deferred && deferred.reject && deferred.reject(err) || console.log(err);
		}
	}, res, query);
};