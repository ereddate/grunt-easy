var fs = require('fs'),
	grunt = require('grunt'),
	iconv = require('iconv-lite'),
	readFile = require('./readDirFiles').read,
	beautify_html = require('js-beautify').html;

function tmpl(html, data) {
	for (name in data) {
		var reg = new RegExp("\\\{\\\{\\s*" + name + "\\s*\\\}\\\}", "gim");
		html = html.replace(reg, data[name]);
	}
	return html;
}

exports.tmpl = function(res, query) {
	console.log(query)
	var dir = query.cmd;


	readFile(dir, function(pathname, deferred) {
		var fd = iconv.decode(fs.readFileSync(pathname), "utf8");
		//fd = fd.replace(/\r/gi, "$js-r-n").replace(/\n/gi, "$js-n-r");
		var contents = fd.split(/\<\!\-\-/);
		//console.log(contents)

		var html = [];
		for (var i = 0; i < contents.length; i++) {
			//console.log(/\s*ng\-/.test(contents[i]))
			if (!/\s*ng\-/.test(contents[i])) {
				html.push(contents[i]);
			} else {
				var temp = contents[i];
				var htmls = /\s+ng\-repeat\s*\=\s*[\"|\']\s*((.+)\/(.+))\s*[\"|\']\s*\:\s*([^]*)\s+\-\-\>/gim.exec(temp);
				//console.log(htmls.length)
				if (htmls && htmls.length > 1) {
					var result = grunt.file.readJSON(pathname.replace(/\/tmpl\/(.+)\.tmpl/gi, "") + "/" + htmls[2] + "/" + htmls[3] + ".json");
					//console.log(result)
					if (result && result.data && result.data.length > 0) {
						var shtml = [];
						for (var x = 0; x < result.data.length; x++) {
							shtml.push(tmpl(htmls[4], result.data[x]))
						}
						temp = temp.replace(htmls[0], shtml.join(''));
						html.push(temp);
					}
				}
			}
		}
		var filename = pathname.replace(/\/tmpl\//, "/modules/").replace(/\.tmpl/, ".html");
		console.log("filename: " + filename)
		try {
			fs.writeFileSync(filename, beautify_html(html.join(''), {
				indent_size: 4,
				indent_char: " ",
				indent_with_tabs: false,
				preserve_newlines: true,
				max_preserve_newlines: 10,
				wrap_line_length: 0,
				indent_inner_html: false,
				brace_style: "collapse"
			}));
		} catch (err) {
			deferred && deferred.reject && deferred.reject(err) || console.log(err);
		}
		/*var htmls = /\<\!\-\-\s+ng\-repeat\s*\=\s*[\"|\']\s*((.+)\/(.+))\s*[\"|\']\s*\:\s*([^]*)\s+\-\-\>/gim.exec(fd);
		console.log(htmls)
		if (htmls && htmls.length > 1) {
			var result = grunt.file.readJSON(pathname.replace(/\/tmpl\/(.+)\.tmpl/gi, "") + "/" + htmls[2] + "/" + htmls[3] + ".json");
			//console.log(result)
			if (result.data && result.data.length > 0) {
				var html = [];
				for (var i = 0; i < result.data.length; i++) {
					html.push(tmpl(htmls[4], result.data[i]))
				}
				fd = fd.replace(htmls[0], html.join(''));
				var filename = pathname.replace(/\/tmpl\//, "/modules/").replace(/\.tmpl/, ".html");
				console.log("filename: " + filename)
				console.log("-----------------------------------")
				console.log("html: " + fd)
				console.log("-----------------------------------")
				try {
					fs.writeFileSync(filename, beautify_html(fd, {
						indent_size: 4,
						indent_char: " ",
						indent_with_tabs: false,
						preserve_newlines: true,
						max_preserve_newlines: 10,
						wrap_line_length: 0,
						indent_inner_html: false,
						brace_style: "collapse"
					}));
				} catch (err) {
					deferred.reject(err);
				}
			}
		}
		//grunt.file.readJSON()
		/*var filename = pathname.replace(/\.html/, "." + query.tcode + ".html");
		console.log(filename);
		try {
			fs.writeFileSync(filename, iconv.encode(iconv.decode(fs.readFileSync(pathname), query.fcode), query.tcode));
		} catch (err) {
			deferred.reject(err);
		}*/
	}, res, query);
};