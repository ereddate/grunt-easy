var server = require("./server");
var router = require("./routes");
var requestHandlers = require("./requestHandlers");
//区分大小写的  
var handle = {}
handle["/"] = requestHandlers.start;

server.start();