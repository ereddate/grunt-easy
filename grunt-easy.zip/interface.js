exports.api = function(ops) {
	var app = ops.app,
		cluster = ops.cluster,
		url = ops.url,
		s_config = ops.s_config,
		routes = ops.routes;
	app.get("/", function(req, res) {
		console.log('worker' + cluster.worker.id)
		var query = url.parse(req.url, true).query;
		console.log("PATH: " + req.url)
		routes.index(s_config, res, query);
	});

	app.post(/\/cmdexec/, function(req, res) {
		console.log('worker' + cluster.worker.id)
		var query = req.body; //ops.url.parse(req.url, true).query;
		console.log("PATH: " + req.url)
		routes.cmdexec(res, query);
	});

	app.post(/\/transcode/, function(req, res) {
		console.log('worker' + cluster.worker.id)
		var query = req.body; //ops.url.parse(req.url, true).query;
		console.log("PATH: " + req.url)
		routes.transcode(res, query);
	});

	app.get(/\/message/, function(req, res){
		console.log('worker' + cluster.worker.id)
		var query = url.parse(req.url, true).query;
		console.log("PATH: " + req.url)
		routes.message(res, query);
	});

	app.get(/\/client/, function(req, res){
		console.log('worker' + cluster.worker.id)
		var query = url.parse(req.url, true).query;
		console.log("PATH: " + req.url)
		routes.client(res, query);
	});

	app.get(/\/tmpl/, function(req, res){
		console.log('worker' + cluster.worker.id)
		var query = url.parse(req.url, true).query;
		console.log("PATH: " + req.url)
		routes.tmpl(res, query);
	});

	app.get('*', function(req, res) {
		console.log('worker' + cluster.worker.id)
		console.log("PATH: " + req.url)
		res.render(req.url, function(err, html) {
			if (err) {
				routes.err(res, '404');
			}
		});
	});
};