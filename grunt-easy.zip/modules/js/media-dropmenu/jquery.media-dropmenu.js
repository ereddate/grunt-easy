(function($) {
	$.fn.mediaDropMenu = function(ops) {
		$(this).find(".menumore").click(function() {
			var p = $(this).parent(),
				isShow = p.hasClass('show_menu');
			$(this).html(isShow ? ops.buttonShowText || "MENU" : ops.buttonCloseText || "CLOSE");
			var self = this;
			p[isShow ? "removeClass" : "addClass"]('show_menu');
			if (isShow) {
				$(".mask").remove();
				if ($.fn.fullpage) {
					$.fn.fullpage.setAllowScrolling(true);
					if (ops.autoScrolling) $.fn.fullpage.setAutoScrolling(false);
				}
			} else {
				$("body").append($("<div></div>").addClass("mask").addClass('show').click(function() {
					$(self).html(ops.buttonShowText || "MENU");
					p.removeClass('show_menu');
					if ($.fn.fullpage) {
						$.fn.fullpage.setAllowScrolling(true);
						if (ops.autoScrolling) $.fn.fullpage.setAutoScrolling(false);
					}
					$(this).remove();
				}));
				if ($.fn.fullpage) {
					$.fn.fullpage.setAllowScrolling(false);
					if (ops.autoScrolling) $.fn.fullpage.setAutoScrolling(true);
				}
			}
		});
		/*.parent().find(".menu_list a").click(function(e) {
					if ($.fn.fullpage) {
						e.preventDefault();
						$.fn.fullpage.moveTo($(this).index() + 1);
					}
				});*/
	};
})(jQuery);