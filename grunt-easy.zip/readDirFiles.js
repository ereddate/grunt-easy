var Q = require('q'),
	fs = require('fs');
Array.prototype.inarray = function(elem) {
	"use strict";
	var l = this.length;
	while (l--) {
		if (this[l] === elem) {
			return true;
		}
	}
	return false;
};

function readFile(dir, callback, res, query) {
	var file_type = ['html', 'htm', 'tmpl'];
	console.log(dir)
	var files = fs.readdirSync(dir);
	var def = function() {
		var deferred = Q.defer();
		files && files.forEach(function(file) {
			var pathname = dir + '/' + file,
				stat = fs.lstatSync(pathname);
			if (!stat.isDirectory()) {
				var name = file.toString();
				if (!file_type.inarray(name.substring(name.lastIndexOf('.') + 1))) {
					return;
				}
				callback && callback(pathname);
			} else {
				readFile(pathname, callback, res, query);
			}
		});
		deferred.resolve();
		return deferred.promise;
	};
	def().then(function() {
		res && res.send({
			status: 1,
			msg: 'end!',
			code: ""
		});
	}, function(err) {
		res && res.send({
			status: 0,
			msg: 'error!',
			code: err
		});
	});
}
exports.read = function(dir, callback, res, query) {
	readFile(dir, callback, res, query);
};