function start() {
	console.log("Request handler 'start' was called.");
}
exports.start = start;