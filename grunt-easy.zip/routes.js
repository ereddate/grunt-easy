var common = require('./views/common/common'),
	minhtml = require('html-minifier').minify,
	//api = require('./interface').api,
	//Q = require('q'),
	//fs = require('fs'),
	//iconv = require('iconv-lite'),
	htmlTmpl = require("./htmltmpl").tmpl,
	head = require('./views/data/head').data,
	http = require('http');
//cheerio = require('cheerio');

function route(handle, pathname) {
	console.log("About to route a request for " + pathname);
	if (typeof handle[pathname] === 'function') {
		handle[pathname]();
	} else {
		console.log("No request handler found for " + pathname);
	}
}

var htmlencode = require("./htmlencode").encode;

function transcode(res, query) {
	htmlencode(res, query);
	/*console.log(query)
	var dir = query.cmd;

	function readFile(dir) {
		var file_type = ['html', 'htm'];
		var files = fs.readdirSync(dir);
		var def = function() {
			var deferred = Q.defer();
			files.forEach(function(file) {
				var pathname = dir + '/' + file,
					stat = fs.lstatSync(pathname);
				if (!stat.isDirectory()) {
					var name = file.toString();
					if (!file_type.inarray(name.substring(name.lastIndexOf('.') + 1))) {
						return;
					}
					var filename = dir + "/" + file.replace(/\.html/, "." + query.tcode + ".html");
					var regex = new RegExp("\\." + query.tcode + "\\.", "gi");
					if (regex.test(file)) {
						res.send({
							status: 0,
							msg: 'error!',
							code: "File already exists."
						});
						return;
					}
					console.log(filename);
					fs.writeFile(filename, iconv.encode(iconv.decode(fs.readFileSync(pathname), query.fcode), query.tcode), function(err) {
						if (err) {
							deferred.reject(err);
						}
					});
				} else {
					readFile(pathname);
				}
			});
			deferred.resolve();
			return deferred.promise;
		};
		def().then(function() {
			res.send({
				status: 1,
				msg: 'success!',
				code: ""
			});
		}, function(err) {
			res.send({
				status: 0,
				msg: 'error!',
				code: err
			});
		});
	}
	readFile(dir);*/
}

function tmpl (res, query){
	htmlTmpl(res, query);
}

function cmdexec(res, query) {
	console.log(query)
	var exec = require('child_process').exec;
	if (query.cmd) {
		var cmd = query.cmd.split(',');
		var cmdStr = 'grunt ';
		for (i = 0; i < cmd.length; i++) cmdStr += query.pname + "-" + cmd[i] + " ";
	} else if (query.cmds) {
		cmdStr = query.cmds;
	}
	exec(cmdStr, function(err, stdout, stderr) {
		console.log(err)
		console.log(stdout)
		console.log(stderr)
		if (!err) {
			res.send({
				status: 1,
				msg: 'success!',
				code: stdout
			});
		} else {
			res.send({
				status: 0,
				msg: 'error!',
				code: err.cmd
			});
		}
	});
}

function index(config, res, query) {
	res.render('index', head, function(err, html) {
		res.send(html);
	});
	/*common.callbacks(api.homeApi(query), function(arr, args) {
		var banners = arr['banner'],
			hotZhuanti = arr['hotZhuanti'];
		if (banners && typeof banners == "string") {
			banners = common.parse(banners);
		}
		if (hotZhuanti && typeof hotZhuanti == "string") {
			hotZhuanti = common.parse(hotZhuanti);
		}
		var str = JSON.stringify(hotZhuanti),
			fTmpl = common.tmpl;
		fTmpl('banner', banners.data ? banners.data : {}, res, args[0], function(banneritems) {
			fTmpl('waterfallitems', hotZhuanti.data ? hotZhuanti.data : {}, res, args[1], function(waterfallitems) {
				*/
	//common.readfile([api.sendpage], function(arr, args) {
	//res.send(arr["sendpage"]);
	/*var header = arr['header'],
		footer = arr['footer'],
		htmlTmpl = arr['tmpl'],
		css = arr['index'];*/
	/*html = minhtml(html.tmpl({
		listData: str,
		waterfall: waterfallitems,
		banners: banneritems,
		header: header,
		footer: footer,
		css: css,
		tmpl: htmlTmpl
	}), {
		removeComments: true,
		collapseWhitespace: true
	});*/
	//});
	/*
				});
			});
		});*/
}

function err(res, type) {
	res.render(type, head);
}

exports.route = route;
exports.index = index;
exports.err = err;
exports.cmdexec = cmdexec;
exports.transcode = transcode;
exports.message = function(res, query){
	res.render('message', function(err, html) {
		res.send(html);
	});
};
exports.client = function(res, query){
	res.render('client', function(err, html) {
		res.send(html);
	});
};

exports.tmpl = tmpl;