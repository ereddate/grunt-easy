var express = require('express'),
  http = require("http"),
  url = require("url"),
  path = require("path"),
  hjs = require('hjs'),
  api = require("./interface").api,
  s_config = require("./server-config").config,
  //common = require('./modules/common'),
  routes = require('./routes'),
  os = require('os'),
  numCPUs = os.cpus().length,
  cluster = require('cluster'),
  domainA = require('domain');
//console.log('cpus: ' + numCPUs)
//compress = require('compression')();

function start() {

  var app = express();

  //console.log(app.get('env'))

  app.set('env', 'development');
  app.set('view engine', 'hjs');
  app.use(express.compress({
    filter: function(req, res) {
      return /json|text|javascript|css/.test(res.getHeader('Content-Type'));
    },
    level: 9
  }));
  app.use(express.favicon());
  app.use(express.logger());
  app.use(express.bodyParser());
  app.use(express.methodOverride());

  if ('development' == app.get('env')) {
    app.set('hostname', s_config.ip);
    app.set('port', s_config.port);
    app.set('views', __dirname + "/views");
    app.use("/", express.static(path.join(__dirname, '/')));
    app.use(express.errorHandler());
  }

  if ('production' == app.get('env')) {
    app.set('hostname', '127.0.0.1')
    app.set('port', 3000);
    app.set('views', __dirname + "/views");
    app.use("/", express.static(path.join(__dirname, '/')));
  }

  app.use(app.router);

  app.locals({
    title: 'ereddate',
    email: 'ereddate@gmail.com',
    phone: '0000'
  });

  if (cluster.isMaster) {
    os.cpus().forEach(function() {
      cluster.schedulingPolicy = cluster.SCHED_NONE;
      var work_process = cluster.fork();
      work_process.on('message', function(msg) {
        //console.log('get message: ' + msg.cmd)
      });
    });

    cluster.on("death", function() {
      console.log('[master] ' + worker.pid + ' died. restart...');
      process.nextTick(function() {
        cluster.fork();
      });
    });

    cluster.on('fork', function(worker) {
      console.log('[master] ' + 'fork: worker' + worker.id);
    });

    cluster.on('online', function(worker) {
      console.log('[master] ' + 'online: worker' + worker.id);
    });

    cluster.on('listening', function(worker, address) {
      console.log('[master] ' + 'listening: worker' + worker.id + ',pid:' + worker.process.pid + ', Address:' + address.address + ":" + address.port);
    });

    cluster.on('disconnect', function(worker) {
      console.log('[master] ' + 'disconnect: worker' + worker.id);
    });

    cluster.on('exit', function(worker, code, signal) {
      console.log('[master] ' + 'exit worker' + worker.id + ' died');
    });
  } else if (cluster.isWorker) {
    console.log('[worker] ' + "start worker ..." + cluster.worker.id);
    process.on('message', function(msg) {
      console.log('[worker] ' + msg);
      process.send('[worker] worker' + cluster.worker.id + ' received!');
    });

    api({
      app: app,
      routes: routes,
      s_config: s_config,
      cluster: cluster,
      url: url
    });

    /*app.get("/", function(req, res) {
      console.log('worker' + cluster.worker.id)
      var query = url.parse(req.url, true).query;
      console.log("PATH: " + req.url)
      routes.index(s_config, res, query);
    });

    app.get(/\/cmdexec/, function(req, res) {
      console.log('worker' + cluster.worker.id)
      var query = url.parse(req.url, true).query;
      console.log("PATH: " + req.url)
      routes.cmdexec(res, query);
    });

    app.get(/\/transcode/, function(req, res) {
      console.log('worker' + cluster.worker.id)
      var query = url.parse(req.url, true).query;
      console.log("PATH: " + req.url)
      routes.transcode(res, query);
    });

    app.get('*', function(req, res) {
      console.log('worker' + cluster.worker.id)
      console.log("PATH: " + req.url)
      res.render(req.url, function(err, html) {
        if (err) {
          routes.err(res, '404');
        }
      });
    });*/

    var domain = domainA.create();

    var connect = http.createServer(app).listen(app.get('port'), function() {
      console.log('server start.')
      console.log('port: ' + app.get('port'))
        /*process.send({
          cmd: 'send message!'
        });*/
    });
    connect.domain = domain;
    //var socket = require('./socketio.server').socketio;
    //socket(connect);
    domain.on('error', function(err) {
      console.log('domain error: ' + err)
    });
  }
}

exports.start = start;