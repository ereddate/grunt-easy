var sio = require('socket.io');

var model = function(ops) {
	return new model.fn.init(ops);
};
model.fn = model.prototype = {
	init: function(ops) {
		this.socket = ops.socket;
		return this;
	},
	showAllInfo: function(room) {
		//socket && (this.socket = socket);
		//socket = socket || this.socket;
		console.log(model.messages[room])
		if (room in model.messages)
			for (name in model.messages[room]) {
				for (i = 0; i < model.messages[room][name].length; i++) {
					if (!/disconnect|login/.test(model.messages[room][name][i])) {
						this.socket.broadcast.to(room).emit("message", model.messages[room][name][i]);
					}
				}
			}
		return this;
	},
	on: function(event, callback) {
		var self = this;
		self.socket.on(event, function(msg) {
			callback.call(self.socket, self, msg);
		});
		return self;
	}
};
model.messages = {};
model.fn.init.prototype = model.fn;
exports.socketio = function(connect) {
	io = sio.listen(connect);
	io.sockets.on("connection", function(socket) {
		model({
			socket: socket
		}).on("my room", function(data) {
			this.join("my room");
		}).on("message", function(self, msg) {
			//self.room = msg.room;
			console.log(msg);
			if (!/disconnect|login/.test(msg.info)) {
				if (!(this.id in model.messages)) {
					model.messages[msg.room] = {};
					model.messages[msg.room][this.id] = [];
				}
				console.log("message")
				model.messages[msg.room][this.id].push(msg.info);
				this.broadcast.to(msg.room).emit("message", msg.info);
			}
			if (/login/.test(msg.info)) {
				console.log("login")
				this.emit("message", msg.username + " join.");
			}
			//this.send(msgval);
		}).on("disconnect", function(self, err) {
			var args = arguments;
			//console.log(args)
			//if (args[0].room in model.messages) model.messages[args[0].room][this.id].push("disconnect");
			console.log("socket disconnect.");
		}).on('anything', function(data) {
			console.log("socket anything.");
			console.log(data)
		});
	});
};