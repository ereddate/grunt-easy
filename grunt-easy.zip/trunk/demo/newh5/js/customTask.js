module.exports = function() {
	console.log("require task ok!");
};