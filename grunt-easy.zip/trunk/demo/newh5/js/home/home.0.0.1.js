﻿(function(win, $) {
	$(".header").mediaDropMenu({
		buttonShowText: "菜单",
		buttonCloseText: "关闭",
		autoScrolling: false
	});
	$('#dowebok').data("isNext", false).fullpage({
		//scrollBar: true,
		//verticalCentered: false,
		css3: false,
		anchors: ['page1', 'page2', 'page3', 'page4', 'page5'],
		//loopTop:true,
		//loopBottom:true,
		//autoScrolling: false,
		//scrollOverflow: true,
		//navigation: true,
		//navigationTooltips: [1, 2, 3, 4],
		//showActiveTooltip: true,
		//slidesNavigation: true,
		afterLoad: function(link, index) {
			console.log(index);
			//$(".header p a").removeClass('active').eq(index - 1).addClass('active');
			switch (index) {
				case 1:
					$(".animate0").addClass('ani_active');
					$(".animate1").removeClass('ani_active');
					break;
				case 2:
					$(".animate1").removeClass('ani_active');
					break;
				case 3:
					$(".animate1").addClass('ani_active');
					break;
			}
		},
		onLeave: function(index, next, direction) {
			switch (index) {
				case 1:
					$(".animate0").removeClass('ani_active');
					$(".animate1").addClass('ani_active');
					break;
				case 2:
					//$(".animate0").removeClass('ani_active');
					break;
				case 3:
					break;
			}
			/*var go = $('#dowebok').data("isNext");
			if ((index == 2 || index == 4) && !go && direction == "up" && (next == 1 || next == 3)) {
				$.fn.fullpage.moveSlideLeft();
				return false;
			} else if ((index == 2 || index == 4) && !go && direction == "down" && (next == 3 || next == 5)) {
				$.fn.fullpage.moveSlideRight();
				return false;
			} else {
				$.fn.fullpage.moveTo(next);
				$('#dowebok').data("isNext", false);
			}*/
		},
		afterRender: function() {
			//console.log("The resulting DOM structure is ready");
		},
		afterResize: function() {
				//console.log("The sections have finished resizing");
			}
			/*,
					afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex) {
						//进入一屏并加载完成以后
						if ((index == 2 || index == 4) && /0|2/.test(slideIndex + "")) {
							$('#dowebok').data("isNext", true);
						}
					},
					onSlideLeave: function(anchorLink, index, slideIndex, direction, nextSlideIndex) {
						//离开一屏并完成以后
					}*/
	});
})(this, jQuery);