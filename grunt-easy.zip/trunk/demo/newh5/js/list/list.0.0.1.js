(function(win, $) {
	var doc = win.document;
	$(".header").mediaDropMenu({
		buttonShowText: "菜单",
		buttonCloseText: "关闭",
		autoScrolling: false
	});

	$(".slide").css({
		width: $(".slide").eq(0).width()
	});
	$("#banner_view").css({
		width: $(".slide").length * $(".slide").eq(0).width()
	});


	var myScroll = new IScroll('#list', {
		scrollbars: true,
		mouseWheel: true,
		interactiveScrollbars: true,
		shrinkScrollbars: 'scale',
		fadeScrollbars: true
	});

	var myScroll1 = new IScroll('#banner', {
		scrollX: true,
		scrollY: false,
		momentum: false,
		snap: true,
		snapSpeed: 400,
		keyBindings: true,
		indicators: {
			el: doc.getElementById('indicator'),
			resize: false
		}
	});

	/*doc.addEventListener('touchmove', function(e) {
		e.preventDefault();
	}, false);*/

})(this, jQuery);