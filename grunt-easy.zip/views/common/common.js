var http = require("http"),
	fs = require('fs');

function isEmptyObject(obj) {
	var name;
	for (name in obj) {
		return false;
	}
	return true;
}

function parse(text) {
	/*检查JSON字符串的有效性*/
	if (text && typeof text == "string" && /^[[\],:{}\s0]*$/.test(text.replace(/\\\\|\\"|\\'|\w+\s*\:|null|true|false|[+\-eE.]|new Date(\d*)/g, '0').replace(/"[^"]*"|'[^']*'|\d+/g, '0'))) {
		return new Function('return (' + text + ');')();
	}
	/*无效的JSON格式*/
	throw 'Invalid JSON format in executing JSON.parse';
};

function each(arr, callback) {
	var len = arr.length,
		i = 0;
	for (i = 0; i < len; i++) {
		var result = callback.call(arr[i], i, arr[i]);
		if (result == false) break;
	}
}

function eachToString(arr) {
	var farr = [];
	each(arr, function(i, obj) {
		farr.push(JSON.stringify(obj));
	});
	return "[" + farr.join(',') + "]";
}

function rTmpl(name, data, res, args, callback) {
	var shtml = [];
	//console.log(args)
	res.render(name, {}, function(err, html) {
		each(data, function(i, obj) {
			if (args.size && i + 1 >= args.size) return false;
			shtml.push(html.tmpl(data[i]));
		});
		//console.log(shtml.join(''))
		if (callback) callback(shtml.length > 0 ? shtml.join('') : html);
		//res.send(html);
	});
}

var rdNum = 0,
	rdData = {};

function readers(args, callback){
	readfile(args, rdNum, callback);
}

function readfile(args, num, callback) {
	fs.readFile(args[num].url, function(err, css) {
		console.log(err)
		rdData[args[num].name] = err ? "" : css;
		num += 1;
		if (num >= args.length) {
			if (callback) callback(rdData, args);
		} else {
			readfile(args, num, callback);
		}
	});
}

function extend(obj, options) {
	var args = arguments,
		len = args.length;
	if (len == 1) {
		options = obj;
		obj = {};
	}
	for (name in options) {
		obj[name] = options[name];
	}
	return obj;
}

var cbNum = 0,
	cbData = {};

function callbacks(args, callback) {
	callbackGo(args, cbNum, callback);
}

function callbackGo(args, num, callback) {
	request(args[num], function(datas) {
		cbData[args[num].name] = datas;
		num += 1;
		if (num >= args.length) {
			if (callback) callback(cbData, args);
		} else {
			callbackGo(args, num, callback);
		}
	});
}

var request = function(ops, callback) {
	return new request.fn.init(ops, callback);
};
request.fn = request.prototype = {
	init: function(ops, callback) {
		var data = "";
		//console.log(ops.path)
		var req = http.request(ops, function(res) {
			//console.log('STATUS: ' + res.statusCode);
			res.setEncoding(ops.encode);
			res.on('data', function(chunk) {
				//console.log('STATUS: readData');
				data += chunk
			}).on('end', function() {
				//console.log('STATUS: end');
				if (callback) callback(data);
			});
		});
		req.on('error', function(e) {
			//console.log('problem with request: ' + e.message);
			if (callback) callback({});
		});
		req.end();
		return this;
	}
};
request.fn.init.prototype = request.fn;

var tmpl = (function() {
		var tmplFuns = {};
		var sArrName = "sArrCMX",
			sLeft = sArrName + '.push("';
		var tags = {
			'=': {
				tagG: '=',
				isBgn: 1,
				isEnd: 1,
				sBgn: '",encode4HtmlValue(',
				sEnd: '),"'
			},
			'js': {
				tagG: 'js',
				isBgn: 1,
				isEnd: 1,
				sBgn: '");',
				sEnd: ';' + sLeft
			},
			'js': {
				tagG: 'js',
				isBgn: 1,
				isEnd: 1,
				sBgn: '");',
				sEnd: ';' + sLeft
			},
			'if': {
				tagG: 'if',
				isBgn: 1,
				rlt: 1,
				sBgn: '");if',
				sEnd: '{' + sLeft
			},
			'elseif': {
				tagG: 'if',
				cond: 1,
				rlt: 1,
				sBgn: '");} else if',
				sEnd: '{' + sLeft
			},
			'else': {
				tagG: 'if',
				cond: 1,
				rlt: 2,
				sEnd: '");}else{' + sLeft
			},
			'/if': {
				tagG: 'if',
				isEnd: 1,
				sEnd: '");}' + sLeft
			},
			'for': {
				tagG: 'for',
				isBgn: 1,
				rlt: 1,
				sBgn: '");for',
				sEnd: '{' + sLeft
			},
			'/for': {
				tagG: 'for',
				isEnd: 1,
				sEnd: '");}' + sLeft
			},
			'while': {
				tagG: 'while',
				isBgn: 1,
				rlt: 1,
				sBgn: '");while',
				sEnd: '{' + sLeft
			},
			'/while': {
				tagG: 'while',
				isEnd: 1,
				sEnd: '");}' + sLeft
			}
		};
		return function(sTmpl, opts) {
			var fun = tmplFuns[sTmpl];
			if (!fun) {
				var N = -1,
					NStat = [];
				var ss = [
					[/\{strip\}([\s\S]*?)\{\/strip\}/g,
						function(a, b) {
							return b.replace(/[\r\n]\s*\}/g, " }").replace(/[\r\n]\s*/g, "");
						}
					],
					[/\\/g, '\\\\'],
					[/"/g, '\\"'],
					[/\r/g, '\\r'],
					[/\n/g, '\\n'],
					[
						/\{[\s\S]*?\S\}/g,
						function(a) {
							a = a.substr(1, a.length - 2);
							for (var i = 0; i < ss2.length; i++) {
								a = a.replace(ss2[i][0], ss2[i][1]);
							}
							var tagName = a;
							if (/^(=|.\w+)/.test(tagName)) {
								tagName = RegExp.$1;
							}
							var tag = tags[tagName];
							if (tag) {
								if (tag.isBgn) {
									var stat = NStat[++N] = {
										tagG: tag.tagG,
										rlt: tag.rlt
									};
								}
								if (tag.isEnd) {
									if (N < 0) {
										throw new Error("Unexpected Tag: " + a);
									}
									stat = NStat[N--];
									if (stat.tagG != tag.tagG) {
										throw new Error("Unmatch Tags: " + stat.tagG + "--" + tagName);
									}
								} else if (!tag.isBgn) {
									if (N < 0) {
										throw new Error("Unexpected Tag:" + a);
									}
									stat = NStat[N];
									if (stat.tagG != tag.tagG) {
										throw new Error("Unmatch Tags: " + stat.tagG + "--" + tagName);
									}
									if (tag.cond && !(tag.cond & stat.rlt)) {
										throw new Error("Unexpected Tag: " + tagName);
									}
									stat.rlt = tag.rlt;
								}
								return (tag.sBgn || '') + a.substr(tagName.length) + (tag.sEnd || '');
							} else {
								return '",(' + a + '),"';
							}
						}
					]
				];
				var ss2 = [
					[/\\n/g, '\n'],
					[/\\r/g, '\r'],
					[/\\"/g, '"'],
					[/\\\\/g, '\\'],
					[/\$(\w+)/g, 'opts["$1"]'],
					[/print\(/g, sArrName + '.push(']
				];
				for (var i = 0; i < ss.length; i++) {
					sTmpl = sTmpl.replace(ss[i][0], ss[i][1]);
				}
				if (N >= 0) {
					throw new Error("Lose end Tag: " + NStat[N].tagG);
				}

				sTmpl = sTmpl.replace(/##7b/g, '{').replace(/##7d/g, '}').replace(/##23/g, '#');
				sTmpl = 'var ' + sArrName + '=[];' + sLeft + sTmpl + '");return ' + sArrName + '.join("");';

				tmplFuns[sTmpl] = fun = new Function('opts', sTmpl);
			}
			if (arguments.length > 1) {
				return fun(opts);
			}
			return fun;
		};
	}()),
	encode4HtmlValue = function(s) {
		return encode4Html(s).replace(/"/g, "&quot;").replace(/'/g, "&#039;");
	},
	encode4Html = function(s) {
		var el = document.createElement('pre');
		var text = document.createTextNode(s);
		el.appendChild(text);
		return el.innerHTML;
	};
String.prototype.tmpl = function(data) {
	return tmpl(this, data);
};

exports.isEmptyObject = isEmptyObject;
exports.parse = parse;
exports.tmpl = rTmpl;
exports.each = each;
exports.request = request;
exports.extend = extend;
exports.callbacks = callbacks;
exports.eachToString = eachToString;
exports.readfile = readers;