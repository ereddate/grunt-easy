exports.data = {
	"title": '前端开发网页版',
	"keyword": 'test',
	"description": 'test',
	"icon": '/logo.ico',
	"author": 'test',
	"copyright": '',
	"appleicon": '',
	"encode": 'utf-8'
};