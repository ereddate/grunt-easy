jQuery(function() {
	jQuery(".send").data("isSend", false).click(function() {
		var self = this,
			info = jQuery(".error");
		if (!jQuery(self).data("isSend")) {
			jQuery(self).data("isSend", true).html("执行中...");
			var isCmd = jQuery("input[name=type]:checked").val() == "1" ? true : false;
			var res = [];
			if (isCmd)
				jQuery("input[type=checkbox][name!=htmlencode]").each(function() {
					if (jQuery(this).is(":checked")) {
						res.push(jQuery(this).val());
					}
				});
			jQuery.post(jQuery("#devform").attr("action"), (isCmd ? "cmd=" + res.join(',') + "&pname=" + (jQuery("input[name=pname]").val()).toLowerCase() : "cmds=" + encodeURIComponent((jQuery("input[name=cmds]").val()).toLowerCase())), function(data) {
				if (data.status == 1) {
					if (jQuery("input[name=htmlencode]:checked").length == 1) {
						var proname = /grunt\s*(.+)\-/.exec(jQuery("input[name=cmds]").val());
						jQuery.post(jQuery("input[name=htmlencode]").val(), "cmd=dist/" + (isCmd ? (jQuery("input[name=pname]").val()).toLowerCase() : proname && proname[1]) + "/html&fcode=utf-8&tcode=" + (jQuery("input[name=encode]").val()).toLowerCase(), function(result) {
							if (result.status == 1) {
								alert("Success!");
								info.html(info.html() + "Success:" + result.code + "<br/>--------------------------<br/>");
							} else {
								alert("Error!");
								info.html(info.html() + "Error:" + result.code + "<br/>--------------------------<br/>");
							}
						}, "json").error(function() {
							alert("Error!");
							info.html(info.html() + "Error:" + result.code + "<br/>--------------------------<br/>");
						});
					} else {
						alert("Success!");
						info.html(info.html() + "Success:" + data.code + "<br/>--------------------------<br/>");
					}
				} else {
					alert("Error!");
					info.html(info.html() + "Error:" + data.code + "<br/>--------------------------<br/>");
				}
				jQuery(self).data("isSend", false).html("执行");
				info.animate({
					scrollTop: info[0].scrollHeight
				});
			}, "json").error(function(err) {
				alert("Error!");
				jQuery(self).data("isSend", false).html("执行");
			});
		}
	});
	jQuery("input[name=type]").click(function() {
		jQuery("input[name=type]").prop('checked', false);
		jQuery(".main_view_item_view").removeClass('show');
		jQuery(this).prop('checked', true).parents(".main_view_item").find(".main_view_item_view").addClass('show');
	}).eq(0).click();
});